<?php

namespace Laravolt\Indonesia\Http\Requests\Kecamatan;

class Update extends Store
{
}
