<?php

namespace Laravolt\Indonesia\Http\Requests\Kelurahan;

class Update extends Store
{
}
