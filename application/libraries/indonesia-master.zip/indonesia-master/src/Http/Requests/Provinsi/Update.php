<?php

namespace Laravolt\Indonesia\Http\Requests\Provinsi;

class Update extends Store
{
}
