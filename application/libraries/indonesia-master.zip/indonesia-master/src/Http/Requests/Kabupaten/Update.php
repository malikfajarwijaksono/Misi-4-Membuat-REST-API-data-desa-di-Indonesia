<?php

namespace Laravolt\Indonesia\Http\Requests\Kabupaten;

class Update extends Store
{
}
